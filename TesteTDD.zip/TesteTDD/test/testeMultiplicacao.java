/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import testetdd.Calculo;

/**
 *
 * @author Zena
 */
public class testeMultiplicacao {
    
    public testeMultiplicacao() {
    }
    
    @Test
    public void testVerificarCalculo(){
         int n1 = 2;
        int n2 = 4;
        int total = n1*n2;
        Calculo n = new Calculo(n1,n2);
      
        assertTrue(total== n.testarNumero());
    }
    
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
